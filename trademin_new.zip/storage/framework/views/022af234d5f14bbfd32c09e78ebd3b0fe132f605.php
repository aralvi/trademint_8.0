<?php $__env->startSection('content'); ?>

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Assign</h1>
          <!-- DataTales Example -->

          <div class="container-fluid">
            <ul id="clothingnav1" class="nav nav-tabs" role="tablist">
              <li class="nav-item"> <a class="nav-link active" href="#home20" id="hometab20" role="tab"
                  data-toggle="tab" aria-controls="home" aria-expanded="true">User (<?php echo e(count($users)); ?>)</a> </li>
              <li class="nav-item"> <a class="nav-link" href="#paneTwo30" role="tab" id="hatstab30" data-toggle="tab"
                  aria-controls="hats">Deposit (<?php echo e(count($deposit_requests) - count($users)); ?>)</a> </li>
              <li class="nav-item"> <a class="nav-link" href="#paneTwo40" role="tab" id="hatstab40" data-toggle="tab"
                  aria-controls="hats">Witdraw (<?php echo e(count($withdraw_requests)); ?>)</a> </li>
            </ul>

            <!-- Content Panel -->
            <div id="clothingnavcontent1" class="tab-content">
              <div role="tabpanel" class="tab-pane fade show active" id="home20" aria-labelledby="hometab20">
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">New User Request</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Plan</th>
                            <th>Investment</th>
                            <th>Date</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($user->first_name.' '.$user->last_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->plan); ?></td>
                                <td>$<?php echo e($user->total_amount); ?></td>
                                <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                                <td><a href="<?php echo e(route('user',$user->id)); ?>" class="badge badge-success">View</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                      </table>

                      <!-- DataTales end -->

                    </div>
                  </div>
                </div>
              </div>
              <div role="tabpanel" class="tab-pane fade" id="paneTwo30" aria-labelledby="hatstab30">
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Deposit Request</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Plan</th>
                            <th>Req Amount</th>
                            <th>Date</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $deposit_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($deposit_request->user->status == 'approved'): ?>

                            <tr>
                                <td class="text-capitalize"><?php echo e($deposit_request->user->first_name .' '.$deposit_request->user->last_name); ?></td>
                                <td><?php echo e($deposit_request->user->email); ?></td>
                                <td><?php echo e($deposit_request->user->plan); ?></td>
                                <td>$<?php echo e($deposit_request->deposit); ?></td>
                                <td><?php echo e($deposit_request->created_at->format('Y-m-d')); ?></td>
                                <td><a href="<?php echo e(route('update.transaction.status',['id'=>$deposit_request->id,'status'=>'approved'])); ?>" class="badge badge-success">Approve</a>
                                    <a href="<?php echo e(route('update.transaction.status',['id'=>$deposit_request->id,'status'=>'approved'])); ?>" class="badge badge-danger">Delete</a>
                                    <a href="<?php echo e(asset($deposit_request->proof)); ?>" target="_blank" class="badge badge-info">view</a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>

                      <!-- DataTales end -->

                    </div>
                  </div>
                </div>
              </div>
              <div role="tabpanel" class="tab-pane fade" id="paneTwo40" aria-labelledby="hatstab40">
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Withdraw Requests</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Plan</th>
                            <th>Deposit Amt</th>
                            <th>Date</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $withdraw_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-capitalize"><?php echo e($withdraw_request->user->first_name .' '.$withdraw_request->user->last_name); ?></td>
                            <td><?php echo e($withdraw_request->user->email); ?></td>
                            <td><?php echo e($withdraw_request->user->plan); ?></td>
                            <td>$<?php echo e($withdraw_request->withdraw); ?></td>
                            <td><?php echo e($withdraw_request->created_at->format('Y-mm-d')); ?></td>
                            <td><a href="<?php echo e(route('update.transaction.status',['id'=>$withdraw_request->id,'status'=>'approved'])); ?>" class="badge badge-success">Approve</a>
                                <a href="<?php echo e(route('update.transaction.status',['id'=>$withdraw_request->id,'status'=>'approved'])); ?>" class="badge badge-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>

                      <!-- DataTales end -->

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\trademin_new\resources\views/approval/index.blade.php ENDPATH**/ ?>