<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

     
<style>@page  {size: 800px 1100px; margin:0!important; padding:10px!important}</style>

    <div class="" style="width: 792px;">
        <img src="./uploads/header.png" style="margin-left: 3px;" alt="" srcset="">

        <table style="width: 100%;margin-top:-32px;">
            <tr>
            <td ><img src="./uploads/left-side-bar.png" alt="" srcset=""></td>
            <td style="vertical-align: top;text-align:center"><span style="font-size: 50px; display:block;padding-top:15px; text-transform:capitalize;"><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></span>
                <img src="./uploads/middle.png" alt="" width="100%" srcset="">
                <table style="margin: auto">
                    <tr>
                        <td style="vertical-align: bottom;   padding-bottom: 25px;">
                            <p style="font-size: 20px;text-align:center"><?php echo e(\Carbon\Carbon::now()->format('d / M , Y')); ?></p>
                            <img src="./uploads/underline.png" alt="" srcset="">
                            
                        </td>
                        <td>
                            <img src="./uploads/logo.png" alt="" srcset="">

                        </td>
                        <td style="vertical-align: bottom;text-align:center;  padding-bottom: 25px;">
                            <img src="./uploads/signature.png" alt="" srcset="">
                            <img src="./uploads/underline.png" alt="" srcset="">
                        </td>
                    </tr>
                </table>
            </td>
            <td style="text-align: right;"><img src="./uploads/right-side-bar.png" alt="" srcset=""></td>
        </tr>
        </table>
        <img src="./uploads/bottom.png" style="margin-top: -32px;    margin-left: 3px;" alt="" srcset="">
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trademin_new\resources\views/certificate.blade.php ENDPATH**/ ?>