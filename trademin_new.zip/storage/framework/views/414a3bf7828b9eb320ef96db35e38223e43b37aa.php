<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Profile</h1>



    <div class="container-xl px-4 mt-4">
        <!-- Account page navigation-->

        <hr class="mt-0 mb-4">
        <div class="row">
            <div class="col-xl-4">
                <!-- Profile picture card-->
                <div class="card mb-4 mb-xl-0">
                    <div class="card-body text-center">
                        <!-- Profile picture image-->
                        <img src="<?php echo e(isset($user->avatar)?asset($user->avatar):'http://bootdey.com/img/Content/avatar/avatar1.png'); ?>" id="blah" alt="" width="198"
                            height="200" class="img-account-profile rounded-circle mb-2">
                        <!-- Profile picture help block-->
                        <div class="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB
                        </div>
                        <!-- Profile picture upload button-->

                        <div class="input-group mb-3">
                            <div class="custom-file">
                                <form action="<?php echo e(route('profile.update')); ?>" method="post" enctype="multipart/form-data">
 <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                    <input type="file"  class="form-control-file" name="avatar" id="imgInp">
                                </div>
                            <button class="btn btn-primary" type="submit">Upload Photo</button>

                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <!-- Account details card-->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('profile.update')); ?>" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
                            <!-- Form Group (username)-->
<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <!-- Form Row-->
                            <h3><strong> Personal Details</strong></h3>
                            <div class="row gx-3 mb-3">
                                <!-- Form Group (first name)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputFirstName">First name</label>
                                    <input class="form-control" id="inputFirstName" type="text" name="first_name"
                                        placeholder="Disabled input" value="<?php echo e($user->first_name); ?>" <?php echo e(Auth::user()->role == 'admin' ?'':'disabled'); ?>>

                                </div>
                                <!-- Form Group (last name)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputLastName">Last name</label>
                                    <input class="form-control" id="inputLastName" type="text" name="last_name"
                                        placeholder="Enter your last name" value="<?php echo e($user->last_name); ?>" <?php echo e(Auth::user()->role == 'admin' ?'':'disabled'); ?>>
                                </div>
                            </div>
                            <!-- Form Row        -->
                            <!-- Form Group (email address)-->
                            <div class="mb-3">
                                <label class="small mb-1" for="inputEmailAddress">Email address</label>
                                <input class="form-control" id="inputEmailAddress" type="email" name="email"
                                    placeholder="Enter your email address" value="<?php echo e($user->email); ?>" <?php echo e(Auth::user()->role == 'admin' ?'':'disabled'); ?>>
                            </div>
                            <!-- Form Row-->
                            <div class="row gx-3 mb-3">
                                <!-- Form Group (phone number)-->
                                <hr class="mt-0 mb-4">
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputPhone">Phone number</label>
                                    <input class="form-control" id="inputPhone" type="tel" name="mobile"
                                        placeholder="Enter your phone number" value="<?php echo e($user->mobile); ?>">
                                </div>
                                <!-- Form Group (birthday)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputBirthday">Plan</label>
                                    <input class="form-control" id="inputBirthday" type="text" name="plan"
                                        placeholder="Enter your birthday" value="<?php echo e($user->plan); ?>" <?php echo e(Auth::user()->role == 'admin' ?'':'disabled'); ?>>
                                </div>
                            </div>
                            <h3><strong> Transaction Details</strong></h3>
                            <div class="row gx-3 mb-3">
                                <!-- Form Group (phone number)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputPhone4">Binance Email:</label>
                                    <input class="form-control" id="inputBinanceEmail" type="email" name="binance_email"
                                        placeholder="Enter your binance email" value="<?php echo e($user->binance_email); ?>" <?php echo e(Auth::user()->role == 'admin' ?'':'disabled'); ?>>
                                </div>
                                <!-- Form Group (birthday)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputBirthday3">Binance ID:</label>
                                    <input class="form-control" type="text" name="binance_id"
                                        placeholder="Enter your binance id" value="<?php echo e($user->binance_id); ?>">
                                </div>
                            </div>
                            <h3>Your ID:</h3>
                            <?php $__currentLoopData = $user->paymentProofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentProof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset($paymentProof->media)); ?>" width="198" height="264" alt="" />

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <br>
                            <br>
                            <br>
                            <!-- Save changes button-->
                            <button class="btn btn-primary" type="submit">Save changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    imgInp.onchange = evt => {
  const [file] = imgInp.files
  if (file) {
    blah.src = URL.createObjectURL(file)
  }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\trademin_new\resources\views/profile/edit.blade.php ENDPATH**/ ?>